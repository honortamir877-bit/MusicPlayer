package com.example.musicplayer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val tracks = mutableListOf<Uri>()
    private var index = 0
    private var player: MediaPlayer? = null
    private lateinit var title: TextView
    private lateinit var status: TextView
    private lateinit var seek: SeekBar
    private lateinit var playButton: Button
    private lateinit var playlist: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var userSeeking = false

    private val progressTask = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && p.isPlaying && !userSeeking) {
                seek.progress = p.currentPosition
                status.text = "${time(p.currentPosition)} / ${time(p.duration)}"
            }
            handler.postDelayed(this, 400)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 16, 24)
        window.navigationBarColor = Color.rgb(16, 16, 24)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(20))
            setBackgroundColor(Color.rgb(16, 16, 24))
        }
        fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val heading = text("MY MUSIC", 13f, Color.rgb(167, 139, 250), true)
        root.addView(heading)
        root.addView(text("Музыкальный плеер", 27f, Color.WHITE, true), margin(0, 8, 0, 24))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(30), dp(20), dp(24))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(31, 30, 46)); cornerRadius = dp(22).toFloat()
            }
        }
        val disc = text("♫", 64f, Color.rgb(196, 181, 253), true).apply { gravity = Gravity.CENTER }
        panel.addView(disc)
        title = text("Музыка не выбрана", 20f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; maxLines = 2
        }
        panel.addView(title, margin(0, 18, 0, 6))
        status = text("Добавь песни с телефона", 13f, Color.LTGRAY).apply { gravity = Gravity.CENTER }
        panel.addView(status)
        seek = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(s: SeekBar?) { userSeeking = true }
                override fun onStopTrackingTouch(s: SeekBar?) {
                    val p = player
                    if (p != null && p.duration > 0) p.seekTo((seek.progress.toLong() * p.duration / 1000).toInt())
                    userSeeking = false
                }
                override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) status.text = "Перемотка: ${progress / 10}%"
                }
            })
        }
        panel.addView(seek, margin(0, 18, 0, 4))
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val prev = button("|◀") { changeTrack(-1) }
        playButton = button("▶") { togglePlayback() }
        val next = button("▶|") { changeTrack(1) }
        controls.addView(prev, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(8) })
        controls.addView(playButton, LinearLayout.LayoutParams(0, dp(54), 1.3f).apply { marginEnd = dp(8) })
        controls.addView(next, LinearLayout.LayoutParams(0, dp(54), 1f))
        panel.addView(controls, margin(0, 14, 0, 0))
        root.addView(panel)

        val add = button("＋  Добавить музыку") { openPicker() }
        root.addView(add, margin(0, 22, 0, 14))
        root.addView(text("ПЛЕЙЛИСТ", 12f, Color.rgb(167, 139, 250), true), margin(2, 8, 0, 8))
        playlist = text("Пока пусто", 14f, Color.LTGRAY)
        root.addView(playlist)
        setContentView(root)
        handler.post(progressTask)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 15f; isAllCaps = false; setTextColor(Color.WHITE)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(92, 73, 160)); cornerRadius = dp(14).toFloat()
        }
        setOnClickListener { action() }
    }

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, 41)
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 41 || resultCode != RESULT_OK || data == null) return
        val picked = mutableListOf<Uri>()
        data.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) picked.add(clip.getItemAt(i).uri)
        } ?: data.data?.let { picked.add(it) }
        picked.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            if (!tracks.contains(uri)) tracks.add(uri)
        }
        if (tracks.isNotEmpty()) {
            if (picked.isNotEmpty() && player == null) playTrack(0)
            refreshPlaylist()
            Toast.makeText(this, "Добавлено: ${picked.size}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshPlaylist() {
        playlist.text = tracks.mapIndexed { i, uri ->
            val name = uri.lastPathSegment?.substringAfterLast('/')?.takeLast(36) ?: "Аудиофайл ${i + 1}"
            (if (i == index) "▶  " else "     ") + "${i + 1}. $name"
        }.joinToString("\n\n")
    }

    private fun playTrack(newIndex: Int) {
        if (tracks.isEmpty()) return
        index = (newIndex + tracks.size) % tracks.size
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, tracks[index])
                setOnPreparedListener { mp ->
                    title.text = tracks[index].lastPathSegment?.substringAfterLast('/') ?: "Трек ${index + 1}"
                    seek.max = mp.duration.coerceAtLeast(1)
                    mp.start(); playButton.text = "Ⅱ"
                    status.text = "${time(0)} / ${time(mp.duration)}"
                    refreshPlaylist()
                }
                setOnCompletionListener { changeTrack(1) }
                setOnErrorListener { _, _, _ ->
                    Toast.makeText(this@MainActivity, "Не удалось воспроизвести этот файл", Toast.LENGTH_SHORT).show()
                    changeTrack(1); true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Не удалось открыть аудиофайл", Toast.LENGTH_SHORT).show()
        }
    }

    private fun togglePlayback() {
        val p = player
        if (p == null) {
            if (tracks.isEmpty()) openPicker() else playTrack(index)
            return
        }
        if (p.isPlaying) { p.pause(); playButton.text = "▶" }
        else { p.start(); playButton.text = "Ⅱ" }
    }

    private fun changeTrack(delta: Int) {
        if (tracks.isEmpty()) return
        playTrack(index + delta)
    }

    private fun time(ms: Int): String = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun margin(l: Int, t: Int, r: Int, b: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    override fun onDestroy() {
        handler.removeCallbacks(progressTask)
        player?.release(); player = null
        super.onDestroy()
    }
}
